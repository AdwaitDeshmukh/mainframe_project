const express = require('express');
const path = require('path');
const fs = require('fs');
const { generateJCL, writeJCL, submitJCL, waitForJobCompletion, getJobOutput } = require('../utils/zowe');

const router = express.Router();

// Helper: Generate DB2 timestamp
function getDB2Timestamp() {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    const hh = String(now.getHours()).padStart(2, '0');
    const min = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');
    const us = String(now.getMilliseconds()).padStart(3, '0') + '000';
    return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}.${us}`;
}

// POST /api/transactions/transfer
// Transfer money from one account to another
router.post('/transfer', async (req, res) => {
    try {
        const { fromAcct, toAcct, amount } = req.body;

        // Validate
        if (!fromAcct || !toAcct || !amount) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        if (parseFloat(amount) <= 0) {
            return res.status(400).json({ error: 'Amount must be greater than 0' });
        }

        if (fromAcct === toAcct) {
            return res.status(400).json({ error: 'Cannot transfer to same account' });
        }

        console.log(`\n💸 Transfer: ${fromAcct} -> ${toAcct}, Amount: ${amount}`);

        // Generate JCL
        const templatePath = path.join(process.env.JCL_TEMPLATES_PATH || './jcl-templates', 'transfer_template.jcl');
        
        if (!fs.existsSync(templatePath)) {
            return res.status(500).json({ error: 'JCL template not found' });
        }

        const txnDate = getDB2Timestamp();
        const jclContent = generateJCL(templatePath, {
            FROM_ACCT: fromAcct,
            TO_ACCT: toAcct,
            AMOUNT: parseFloat(amount).toFixed(2),
            TXN_DATE: txnDate
        });

        // Write JCL
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        
        const jclPath = path.join(tempDir, `transfer_${Date.now()}.jcl`);
        writeJCL(jclContent, jclPath);

        // Submit
        const jobId = await submitJCL(jclPath);

        // Wait for completion
        const jobStatus = await waitForJobCompletion(jobId);

        // Get output
        const output = await getJobOutput(jobId);

        console.log('COBOL Output:', output.substring(0, 500));

        // Check if successful
        const isSuccess = output.includes('TRANSFER COMPLETED SUCCESSFULLY');
        const hasInsufficientBalance = output.includes('INSUFFICIENT BALANCE');
        const hasError = output.includes('ERROR');

        // If insufficient balance, return error
        if (hasInsufficientBalance) {
            return res.status(400).json({
                success: false,
                error: 'Insufficient balance in sender account',
                fromAcct,
                toAcct,
                amount
            });
        }

        // If any other error, return error
        if (hasError && !isSuccess) {
            return res.status(400).json({
                success: false,
                error: 'Transfer operation failed',
                fromAcct,
                toAcct,
                amount
            });
        }

        // If successful
        if (isSuccess) {
            return res.json({
                success: true,
                fromAcct,
                toAcct,
                amount,
                txnDate,
                jobId,
                status: jobStatus.status,
                message: 'Transfer completed successfully'
            });
        }

        // Default case
        res.status(400).json({
            success: false,
            error: 'Transfer may have failed - check output',
            fromAcct,
            toAcct,
            amount
        });

    } catch (error) {
        console.error('Transfer error:', error);
        res.status(500).json({ 
            error: 'Transfer failed',
            details: error.message 
        });
    }
});

module.exports = router;