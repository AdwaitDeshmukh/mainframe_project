const express = require('express');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { generateJCL, writeJCL, submitJCL, waitForJobCompletion, getJobOutput } = require('../utils/zowe');

const router = express.Router();

// POST /api/accounts/create
// Create new account (insert into USERS + WALLET)
router.post('/create', async (req, res) => {
    try {
        const { fname, lname, email, pin } = req.body;

        // Validate input
        if (!fname || !lname || !email || !pin) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        if (pin.length !== 4) {
            return res.status(400).json({ error: 'PIN must be 4 digits' });
        }

        // Generate account number (ACC + 10 digits)
        const acctNum = 'ACC' + Math.random().toString().slice(2, 12).padStart(10, '0');

        console.log(`\n📝 Creating account: ${acctNum}`);

        // Generate JCL from template
        const templatePath = path.join(process.env.JCL_TEMPLATES_PATH || './jcl-templates', 'addaccount_template.jcl');
        
        if (!fs.existsSync(templatePath)) {
            return res.status(500).json({ error: 'JCL template not found' });
        }

        const jclContent = generateJCL(templatePath, {
            ACCT_NUM: acctNum,
            FNAME: fname.toUpperCase().padEnd(15),
            LNAME: lname.toUpperCase().padEnd(20),
            EMAIL: email.toLowerCase(),
            PIN: pin
        });

        // Write to temp file
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        
        const jclPath = path.join(tempDir, `addacct_${Date.now()}.jcl`);
        writeJCL(jclContent, jclPath);

        // Submit JCL
        const jobId = await submitJCL(jclPath);

        // Wait for job completion
        const jobStatus = await waitForJobCompletion(jobId);

        // Get output
        const output = await getJobOutput(jobId);

        res.json({
            success: true,
            acctNum,
            jobId,
            status: jobStatus.status,
            message: 'Account created successfully',
            output: output.substring(0, 500) // First 500 chars
        });

    } catch (error) {
        console.error('Create account error:', error);
        res.status(500).json({ 
            error: 'Failed to create account',
            details: error.message 
        });
    }
});

// GET /api/accounts/:acctNum/balance
// Check account balance
router.get('/:acctNum/balance', async (req, res) => {
    try {
        const { acctNum } = req.params;

        console.log(`\n💰 Checking balance for: ${acctNum}`);

        // Generate JCL from template
        const templatePath = path.join(process.env.JCL_TEMPLATES_PATH || './jcl-templates', 'checkbal_template.jcl');
        
        if (!fs.existsSync(templatePath)) {
            return res.status(500).json({ error: 'JCL template not found' });
        }

        const jclContent = generateJCL(templatePath, {
            ACCT_NUM: acctNum
        });

        // Write to temp file
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        
        const jclPath = path.join(tempDir, `chkbal_${Date.now()}.jcl`);
        writeJCL(jclContent, jclPath);

        // Submit JCL
        const jobId = await submitJCL(jclPath);

        // Wait for job completion
        const jobStatus = await waitForJobCompletion(jobId);

        // Get output
        const output = await getJobOutput(jobId);

        // Parse balance from output (simple extraction)
        const balanceMatch = output.match(/BALANCE\s+:\s+([\d.,]+)/);
        const balance = balanceMatch ? balanceMatch[1] : 'N/A';

        const nameMatch = output.match(/NAME\s+:\s+([A-Z\s]+)/);
        const name = nameMatch ? nameMatch[1].trim() : 'Unknown';

        res.json({
            success: true,
            acctNum,
            name,
            balance,
            jobId,
            status: jobStatus.status
        });

    } catch (error) {
        console.error('Check balance error:', error);
        res.status(500).json({ 
            error: 'Failed to check balance',
            details: error.message 
        });
    }
});

module.exports = router;
